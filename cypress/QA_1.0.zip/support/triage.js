Cypress.Commands.add('Investigations', () => {
    

            

        cy.patientTriage('Auto_Test',{delay:500})
        cy.contains('Clinical Investigations').click()
        // Cypress.waitFor(500)
        cy.get('.LabTestsSelectInfinite__container').first().click().type('Breast MRI',{delay:200})
        cy.get('.LabTestsSelectInfinite__item').first().click({force:true})
        // cy.wait(500)
        cy.get('.LabTestsSelectInfinite__container').first().click().type('17-OH Progesterone',{delay:100})
        cy.get('.LabTestsSelectInfinite__item').first().click({force:true})
        cy.get('.form-buttons').contains('Submit').click()
        cy.reload()
        
        // cy.contains('Clinical Investigations')
        // cy.contains('17-OH Progesterone')
        // cy.get('.FeedEntryHeader__status-label').contains('Awaiting Specimen')
        // cy.contains('Take Specimen').click()
        
    

})

Cypress.Commands.add('Prescription', ()=>{
 

        cy.patientTriage()
        cy.contains('Prescriptions').click()
        cy.contains('Select Medication').click('')
        cy.get(':nth-child(1) > .LibraryDataSelectInfinite__item > .ng-binding').first().click({delay:500})
        cy.get('[name="prescription_strength"]').type('500')
        // cy.get('blood-pressure-input').type('120/80')
        cy.get('[name="prescription_dose"]').type('3')
        cy.get('[name="prescription_route_0"]').click()
        cy.get('li').first().click()
        cy.get('[name="prescription_frequency_0"]').click()
        cy.contains('Daily').first().click({force:true})
        cy.get('[name="prescription_period"]').type('3')
        
        cy.get('.form-buttons').contains('Submit').click()
  
})

Cypress.Commands.add('MedicalNotes', ()=>{
    cy.patientTriage()
    cy.contains('Medical Encounter Note').click({force:true})
    cy.contains('General Practice').click().wait(1500)
    cy.contains('Proceed to Note').should('have.attr','disabled','disabled')
    cy.contains('Initial Visit').should('be.visible')
    cy.get('.entry-value').contains('Initial Visit').click()
    cy.contains('Proceed to Note').click()
    cy.contains('You are submitting an Encounter Note').should('be.visible')
    cy.contains('Discard').should('be.visible')
    cy.contains('Save as Draft').should('be.visible')
    cy.get('.form-buttons').contains('Submit').should('be.visible')
    cy.contains('complaints').click()
    cy.get('li').first().click()
    cy.contains('diagnosis').click()
    cy.get('li').first().click()
    cy.get('.form-buttons').contains('Submit').first().click({timeout:500})
    cy.reload()
})

Cypress.Commands.add('Vitals', ()=>{
    cy.patientTriage()
    cy.contains('Vitals').click()
    cy.get('[name="weight"]').type('90')
    cy.get('[name="height"]').type('180')
    cy.get('blood-pressure-input').type('120/80')
    cy.get('[name="bodyTemperature"]').type('37.0')
    cy.get('[name="heartRate"]').type('70')
    cy.get('.form-buttons').contains('Submit').click()
})

Cypress.Commands.add('Immunization', ()=>{
    cy.patientTriage()
    cy.contains('Immunization').click()
    cy.get('[name="vaccineImmunization_0"]').click()
    cy.get('.ui-select-choices-row').first().click()
    cy.get('[name="vaccineDose_0"]').type('0.5ml')
    cy.get('datetimepicker>[name="vaccineReceivedOn_0"]').first().click()
    cy.contains('Today').click()
    cy.get('datetimepicker>[name="vaccineExpiryDate_0"]').first().click()
    cy.contains('Today').click()
    cy.get('[name="vaccineBatchNo_0"]').type('BA-012')
    cy.get('.form-buttons').contains('Submit').click()
    cy.reload()
})

Cypress.Commands.add('Admission', ()=>{
    cy.patientTriage()
    cy.contains('Admit').click()
    cy.get('[placeholder="Select Room"]').first().click()
    cy.get('.ui-select-choices-row-inner').first().click()
    cy.get('.LibraryDataMultiselectInfinite__select').click()
    cy.get('.li').first().click()
    cy.get('[name="summary"]').type('poisoned')
    cy.get('.TextareaWithIncludes__buttons-container').contains('Prescription').click()
    cy.contains('Select Medication').click('').get('.LibraryDataSelectInfinite__item').first().click()
    // cy
    cy.get('[name="prescription_strength"]').type('500')
    // cy.get('blood-pressure-input').type('120/80')
    cy.get('[name="prescription_dose"]').type('3')
    cy.get('[name="prescription_route_0"]').click().contains('PO (by mouth)').click()
    // cy
    cy.get('[name="prescription_frequency_0"]').click()
    cy.contains('Daily').click({force: true})
    cy.get('[name="prescription_period"]').type('3')
    cy.get('.form-buttons').contains('Submit').click()
    cy.contains('Discharge Patient').click()
    cy.get('[placeholder="Describe Reason"]').type('Gbe body e')
    cy.get('.form-buttons').contains('Submit').click()
    
})

Cypress.Commands.add('Comment', ()=>{
    cy.patientTriage()
    cy.contains('Comment').click()
    cy.get('[name="comment"]').type('This patient suffers from amnesia')
    cy.get('.form-buttons').contains('Submit').click()
})

Cypress.Commands.add('Discharge', ()=>{
    cy.patientTriage()
    cy.contains('Discharge').click({force:true})
    
})

Cypress.Commands.add('Search', ()=>{
    cy.contains('Search').click()
    cy.get('[placeholder="Type patient\'s name"]').type('Auto')
    cy.get('div>.SearchModal__patient-row').first().click()
    
})


