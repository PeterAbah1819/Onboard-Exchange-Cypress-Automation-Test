

describe('login',()=>{
  it('login scenerio',() =>{
    cy.login()
    // cy.registerPatient()
    // cy.get('[class="Patients__content-body fade-in-out ng-scope"]')
    // .first()
    // .parent()
    // .click()
  })
})