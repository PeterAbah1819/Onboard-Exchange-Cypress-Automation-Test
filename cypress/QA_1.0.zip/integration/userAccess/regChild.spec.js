describe('Register Child',()=>{
    it('Child Registration scenerio',() =>{
      cy.login()
      cy.registerChild()
    })
  })