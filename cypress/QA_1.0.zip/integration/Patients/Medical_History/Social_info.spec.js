describe('Add Social info', () => {

    it('Add Social Info', () => {

        cy.login();

    it('click on PT Folder')
    //it('For Single registered Patient')
        //cy.get('[class="TagsList__patient-name ng-binding ng-scope"]').click()

    //it('multiple registered PT')
    cy.get('[class="TagsList__patient-name ng-binding ng-scope"]').contains('Caleb').click()

    it('click on Social Info Tab Button')
        cy.get('[class="PatientDetailsBox__tab-link ng-binding"]').contains('Social Info').click()

    })
})