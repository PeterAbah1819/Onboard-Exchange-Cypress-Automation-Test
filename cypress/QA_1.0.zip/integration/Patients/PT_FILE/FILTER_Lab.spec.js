describe('Filter By LAB in PT File', () => {

    it('Filter by Lab', () => {

        cy.login()

        cy.get('[class="TagsList__patient-name ng-binding ng-scope"]').contains('Caleb').click()

        cy.get('.Feed__filter-labs > label > .Feed__filter-label').click()

    })
})