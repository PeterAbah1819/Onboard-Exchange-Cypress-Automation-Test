describe('Filter By Drugs in PT File', () => {

    it('Filter by Drugs', () => {

        cy.login()

        cy.get('[class="TagsList__patient-name ng-binding ng-scope"]').contains('Caleb').click()

        cy.get('.Feed__filter-drugs > label > .Feed__filter-label').click()

    })
})